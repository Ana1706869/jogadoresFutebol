package pt.ipg.livros

import android.database.Cursor
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.Toast
import androidx.loader.app.LoaderManager
import androidx.loader.content.CursorLoader
import androidx.loader.content.Loader
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import pt.ipg.livros.databinding.FragmentNovoJogadorBinding
import java.text.SimpleDateFormat
import java.util.*

private const val ID_LOADER_JOGADORES = 0

/**
 * A simple [Fragment] subclass.
 * Use the [NovoJogadorFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class NovoJogadorFragment : Fragment(){
        private var _binding: FragmentNovoJogadorBinding? = null

        // This property is only valid between onCreateView and
        // onDestroyView.
        private val binding get() = _binding!!

        override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
        ): View? {

            _binding = FragmentNovoJogadorBinding.inflate(inflater, container, false)
            return binding.root

        }

        override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
            super.onViewCreated(view, savedInstanceState)






            val activity = activity as MainActivity
            activity.fragment = this
            activity.idMenuAtual = R.menu.menu_guardar_cancelar
        }

        override fun onDestroyView() {
            super.onDestroyView()
            _binding = null
        }


        fun processaOpcaoMenu(item: MenuItem): Boolean {
            return when (item.itemId) {
                R.id.action_guardar -> {
                    guardar()
                    true
                }
                R.id.action_cancelar -> {
                    voltaListaJogadores()
                    true
                }
                else -> false
            }
        }

        private fun voltaListaJogadores() {
            findNavController().navigate(R.id.action_editarJogadorFragment_to_ListaJogadoresFragment)
        }

        private fun guardar() {
            val editTextId = binding.editTextId.text.toString()
            if (editTextId.isBlank()) {
                binding.editTextId.error = getString(R.string.id_obrigatorio)
                binding.editTextId.requestFocus()
                return
            }
            val id=editTextId.toLong()

            val nome = binding.editTextNome.text.toString()
            if (nome.isBlank()) {
                binding.editTextNome.error = getString(R.string.nome_obrigatorio)
                binding.editTextNome.requestFocus()
                return
            }

            val data: Date
            val df = SimpleDateFormat("dd-MM-yyyy")
            try {
                data = df.parse(binding.editTextDataNascimento.text.toString())
            } catch (e: Exception) {
                binding.editTextDataNascimento.error = getString(R.string.data_invalida)
                binding.editTextDataNascimento.requestFocus()
                return
            }
            val dataNascimento = Calendar.getInstance()
            dataNascimento.time = data


            val clube = binding.editTextTextClube.text.toString()
            if (nome.isBlank()) {
                binding.editTextTextClube.error = getString(R.string.clube_obrigatorio)
                binding.editTextTextClube.requestFocus()
                return
            }

            val nacionalidade = binding.editTextTextNacionalidade.text.toString()
            if (nome.isBlank()) {
                binding.editTextTextNacionalidade.error = getString(R.string.nacionalidade_obrigatoria)
                binding.editTextTextNacionalidade.requestFocus()
                return
            }

            val posicao = binding.editTextTextPosicao.text.toString()
            if (nome.isBlank()) {
                binding.editTextTextPosicao.error = getString(R.string.posicao_obrigatoria)
                binding.editTextTextPosicao.requestFocus()
                return
            }

            val editTextAltura = binding.editTextAltura.text.toString()
            if (nome.isBlank()) {
                binding.editTextAltura.error = getString(R.string.altura_obrigatoria)
                binding.editTextAltura.requestFocus()
                return
            }
            val altura=editTextAltura.toDouble()

            val editTextPeso = binding.editTextPeso.text.toString()
            if (editTextPeso.isBlank()) {
                binding.editTextPeso.error = getString(R.string.peso_obrigatorio)
                binding.editTextPeso.requestFocus()
                return
            }
            val peso=editTextPeso.toInt()

            val editTextInternacionalizacoes = binding.editTextInternacionalizacoes.text.toString()
            if (editTextInternacionalizacoes.isBlank()) {
                binding.editTextInternacionalizacoes.error = getString(R.string.internacionalizacoes_obrigatorias)
                binding.editTextInternacionalizacoes.requestFocus()
                return
            }
            val internacionalizacoes=editTextInternacionalizacoes.toInt()

            val editTextGolos = binding.editTextGolos.text.toString()
            if (editTextGolos.isBlank()) {
                binding.editTextGolos.error = getString(R.string.golos_obrigatorios)
                binding.editTextGolos.requestFocus()
                return
            }
            val golos=editTextGolos.toInt()




            val livro = Jogadores(id, nome, dataNascimento, clube, nacionalidade, posicao, altura, peso, internacionalizacoes, golos
            )

            val idJogadores = requireActivity().contentResolver.insert(
                JogadoresContentProvider.ENDERECO_JOGADORES,
                livro.toContentValues()
            )

            if (idJogadores == null) {
                binding.editTextNome.error = getString(R.string.erro_adicionar_jogador)
                return
            }

            Toast.makeText(requireContext(), getString(R.string.jogador_adicionado_com_sucesso), Toast.LENGTH_SHORT).show()
            voltaListaJogadores()
        }

        /**
         * Instantiate and return a new Loader for the given ID.
         *
         *
         * This will always be called from the process's main thread.
         *
         * @param id The ID whose loader is to be created.
         * @param args Any arguments supplied by the caller.
         * @return Return a new Loader instance that is ready to start loading.
         */

        }

        /**
         * Called when a previously created loader is being reset, and thus
         * making its data unavailable.  The application should at this point
         * remove any references it has to the Loader's data.
         *
         *
         * This will always be called from the process's main thread.
         *
         * @param loader The Loader that is being reset.
         */


        /**
         * Called when a previously created loader has finished its load.  Note
         * that normally an application is *not* allowed to commit fragment
         * transactions while in this call, since it can happen after an
         * activity's state is saved.  See [ FragmentManager.openTransaction()][androidx.fragment.app.FragmentManager.beginTransaction] for further discussion on this.
         *
         *
         * This function is guaranteed to be called prior to the release of
         * the last data that was supplied for this Loader.  At this point
         * you should remove all use of the old data (since it will be released
         * soon), but should not do your own release of the data since its Loader
         * owns it and will take care of that.  The Loader will take care of
         * management of its data so you don't have to.  In particular:
         *
         *
         *  *
         *
         *The Loader will monitor for changes to the data, and report
         * them to you through new calls here.  You should not monitor the
         * data yourself.  For example, if the data is a [android.database.Cursor]
         * and you place it in a [android.widget.CursorAdapter], use
         * the [android.widget.CursorAdapter.CursorAdapter] constructor *without* passing
         * in either [android.widget.CursorAdapter.FLAG_AUTO_REQUERY]
         * or [android.widget.CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER]
         * (that is, use 0 for the flags argument).  This prevents the CursorAdapter
         * from doing its own observing of the Cursor, which is not needed since
         * when a change happens you will get a new Cursor throw another call
         * here.
         *  *  The Loader will release the data once it knows the application
         * is no longer using it.  For example, if the data is
         * a [android.database.Cursor] from a [android.content.CursorLoader],
         * you should not call close() on it yourself.  If the Cursor is being placed in a
         * [android.widget.CursorAdapter], you should use the
         * [android.widget.CursorAdapter.swapCursor]
         * method so that the old Cursor is not closed.
         *
         *
         *
         * This will always be called from the process's main thread.
         *
         * @param loader The Loader that has finished.
         * @param data The data generated by the Loader.
         */









