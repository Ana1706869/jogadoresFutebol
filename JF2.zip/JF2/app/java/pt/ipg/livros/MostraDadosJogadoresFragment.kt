package pt.ipg.livros

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.navigation.fragment.findNavController
import pt.ipg.livros.databinding.FragmentEditarTitulosBinding
import pt.ipg.livros.databinding.FragmentMostraDadosJogadoresBinding


class MostraDadosJogadoresFragment : Fragment() {
    private var jogador:Jogadores?=null
    private var titulo: Titulos? = null
    private var _binding: FragmentMostraDadosJogadoresBinding? = null


    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentMostraDadosJogadoresBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val activity = activity as MainActivity
        activity.fragment = this
        activity.idMenuAtual = R.menu.menu_mostra_dados_jogadores

        val jogador=EditarJogadorFragmentArgs.fromBundle(requireArguments()).jogador
        val titulo =EditarTitulosFragmentArgs.fromBundle(requireArguments()).titulo

        if (titulo != null) {
            binding.textViewCampeontosNacionais3.setText(titulo.campeonatosNacionais.toString())
            binding.textViewTacasPortugal2.setText(titulo.tacasPortugal)
            binding.textViewTacasLiga4.setText(titulo.tacasLiga.toString())
            binding.textViewSupertacas4.setText(titulo.supertacas.toString())
            binding.textViewCampeonatosContinentaisSelecoes4.setText(titulo.campeonatosContinentaisSelecoes.toString())
            binding.textViewCampeonatosMundoSelecoes4.setText(titulo.campeonatosMundoSelecoes.toString())

        }

        this.titulo = titulo

        if (jogador!= null) {
            binding.textViewNome5.setText(jogador.nome)
            binding.textViewDataNascimento2.setText(jogador.dataNascimento.toString())
            binding.textViewClube2.setText(jogador.clube)
            binding.textViewNacionalidade2.setText(jogador.nacionalidade)
            binding.textViewPosicao2.setText(jogador.posicao)
            binding.textViewAltura2.setText(jogador.altura.toString())
            binding.textViewPeso2.setText(jogador.peso.toString())
            binding.textViewInternacionalizacoes2.setText(jogador.internacionalizacoes.toString())
            binding.textViewGolos2.setText(jogador.golos.toString())

        }
        this.jogador=jogador
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    fun processaOpcaoMenu(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_cancelar -> {
                voltarMenuPrincipal()
                true
            }
            else -> false
        }
    }

    private fun voltarMenuPrincipal() {
        findNavController().navigate(R.id.action_mostraDadosJogadoresFragment_to_MenuPrincipalFragment)
    }

    }